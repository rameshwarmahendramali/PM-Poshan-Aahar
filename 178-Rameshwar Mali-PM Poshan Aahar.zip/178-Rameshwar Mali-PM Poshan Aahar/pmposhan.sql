-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 22, 2023 at 09:22 AM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.0.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `pmposhan`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `admin_id` int(25) NOT NULL,
  `admin_uname` varchar(25) NOT NULL,
  `admin_pass` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`admin_id`, `admin_uname`, `admin_pass`) VALUES
(1, 'admin@gmail.com', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `attendance`
--

CREATE TABLE `attendance` (
  `attendance_id` int(20) NOT NULL,
  `school_id` int(50) NOT NULL,
  `present` int(50) NOT NULL,
  `absent` int(50) NOT NULL,
  `total` int(50) NOT NULL,
  `month` int(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `attendance`
--

INSERT INTO `attendance` (`attendance_id`, `school_id`, `present`, `absent`, `total`, `month`) VALUES
(4, 7, 60, 20, 50, 7);

-- --------------------------------------------------------

--
-- Table structure for table `calculated_meal`
--

CREATE TABLE `calculated_meal` (
  `cal_id` int(50) NOT NULL,
  `meal_id` int(50) NOT NULL,
  `supplier_id` int(50) NOT NULL,
  `item` varchar(50) NOT NULL,
  `req_meal` int(50) NOT NULL,
  `used_meal` int(50) NOT NULL,
  `rem_meal` int(50) NOT NULL,
  `unit` varchar(50) NOT NULL,
  `status` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `calculated_meal`
--

INSERT INTO `calculated_meal` (`cal_id`, `meal_id`, `supplier_id`, `item`, `req_meal`, `used_meal`, `rem_meal`, `unit`, `status`) VALUES
(1, 1, 1, 'Rice', 270, 240, 30, 'KG', 'Approve'),
(2, 2, 2, 'Biscuit', 90, 80, 10, 'Piece', 'Disaaprove'),
(3, 3, 3, 'Eggs', 90, 160, 20, 'Piece', 'Disapprove');

-- --------------------------------------------------------

--
-- Table structure for table `complaints`
--

CREATE TABLE `complaints` (
  `complaint_id` int(50) NOT NULL,
  `school_id` int(50) NOT NULL,
  `complaint` varchar(50) NOT NULL,
  `complaint_desc` varchar(50) NOT NULL,
  `doc` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `complaints`
--

INSERT INTO `complaints` (`complaint_id`, `school_id`, `complaint`, `complaint_desc`, `doc`) VALUES
(1, 7, 'bad', 'Bad quality', '2023-07-25');

-- --------------------------------------------------------

--
-- Table structure for table `meal`
--

CREATE TABLE `meal` (
  `meal_id` int(20) NOT NULL,
  `meal_name` varchar(20) NOT NULL,
  `meal_desc` varchar(50) NOT NULL,
  `meal_quantity` int(11) NOT NULL,
  `meal_total` int(11) NOT NULL,
  `unit` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `meal`
--

INSERT INTO `meal` (`meal_id`, `meal_name`, `meal_desc`, `meal_quantity`, `meal_total`, `unit`) VALUES
(1, 'Rice', 'good rice', 3, 90, 'KG'),
(2, 'Biscuit', 'Parle-G', 1, 30, 'Piece'),
(3, 'Eggs', 'Hens Eggs', 2, 60, 'Piece');

-- --------------------------------------------------------

--
-- Table structure for table `remaining_inventory`
--

CREATE TABLE `remaining_inventory` (
  `inventory_id` int(50) NOT NULL,
  `school_id` int(50) NOT NULL,
  `item_name` varchar(50) NOT NULL,
  `m_rem_quantity` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `remaining_inventory`
--

INSERT INTO `remaining_inventory` (`inventory_id`, `school_id`, `item_name`, `m_rem_quantity`) VALUES
(1, 7, 'banana', '2'),
(2, 7, 'rice', '5');

-- --------------------------------------------------------

--
-- Table structure for table `school_login`
--

CREATE TABLE `school_login` (
  `school_id` int(10) NOT NULL,
  `s_name` varchar(100) NOT NULL,
  `s_email` varchar(100) NOT NULL,
  `s_username` varchar(100) NOT NULL,
  `s_password` varchar(100) NOT NULL,
  `s_city` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `school_login`
--

INSERT INTO `school_login` (`school_id`, `s_name`, `s_email`, `s_username`, `s_password`, `s_city`) VALUES
(7, 'RCPIT', 'rcpit@gmail.com', 'rcpitshirpur', 'rcpit', 'Shirpur'),
(9, 'SVKM', 'svkm@gmail.com', 'svkm', 'svkm', 'Dhule'),
(10, 'pharmacy', 'pharmacy@gmail.com', 'pharmacyshirpur', 'pharmacyshirpur', 'shirpur');

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `student_id` int(25) NOT NULL,
  `school_id` int(20) NOT NULL,
  `student_rollno` int(25) NOT NULL,
  `student_name` varchar(100) NOT NULL,
  `student_email` varchar(25) NOT NULL,
  `student_height` int(25) NOT NULL,
  `student_weight` int(25) NOT NULL,
  `student_city` varchar(25) NOT NULL,
  `student_state` varchar(25) NOT NULL,
  `student_zip` int(25) NOT NULL,
  `monthly_attendance` int(20) NOT NULL,
  `attendance_date` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`student_id`, `school_id`, `student_rollno`, `student_name`, `student_email`, `student_height`, `student_weight`, `student_city`, `student_state`, `student_zip`, `monthly_attendance`, `attendance_date`) VALUES
(1, 7, 170, 'Rameshwar', 'rameshwar@gmail.com', 145, 50, 'Betawad', 'MH', 425403, 25, '2023-07-20'),
(4, 9, 125, 'Paresh', 'paresh@gmail.com', 120, 90, 'Shahada', 'MH', 425405, 0, ''),
(5, 7, 178, 'Pruthvi', 'pruthvi@gmail.com', 260, 55, 'Shirpur', 'MH', 425405, 20, '');

-- --------------------------------------------------------

--
-- Table structure for table `supplier`
--

CREATE TABLE `supplier` (
  `sp_id` int(11) NOT NULL,
  `sp_name` varchar(11) NOT NULL,
  `sp_uname` varchar(25) NOT NULL,
  `sp_email` varchar(25) NOT NULL,
  `sp_pass` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `supplier`
--

INSERT INTO `supplier` (`sp_id`, `sp_name`, `sp_uname`, `sp_email`, `sp_pass`) VALUES
(1, 'Sai Shop', 'saishop', 'saishop@gmail.com', 'saishop'),
(3, 'Gopal Grain', 'gopalgrains', 'gopal@gmail.com', 'gopalgrains');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`admin_id`);

--
-- Indexes for table `attendance`
--
ALTER TABLE `attendance`
  ADD PRIMARY KEY (`attendance_id`);

--
-- Indexes for table `calculated_meal`
--
ALTER TABLE `calculated_meal`
  ADD PRIMARY KEY (`cal_id`);

--
-- Indexes for table `complaints`
--
ALTER TABLE `complaints`
  ADD PRIMARY KEY (`complaint_id`);

--
-- Indexes for table `meal`
--
ALTER TABLE `meal`
  ADD PRIMARY KEY (`meal_id`);

--
-- Indexes for table `remaining_inventory`
--
ALTER TABLE `remaining_inventory`
  ADD PRIMARY KEY (`inventory_id`);

--
-- Indexes for table `school_login`
--
ALTER TABLE `school_login`
  ADD PRIMARY KEY (`school_id`);

--
-- Indexes for table `student`
--
ALTER TABLE `student`
  ADD PRIMARY KEY (`student_id`);

--
-- Indexes for table `supplier`
--
ALTER TABLE `supplier`
  ADD PRIMARY KEY (`sp_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `admin_id` int(25) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `attendance`
--
ALTER TABLE `attendance`
  MODIFY `attendance_id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `calculated_meal`
--
ALTER TABLE `calculated_meal`
  MODIFY `cal_id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `complaints`
--
ALTER TABLE `complaints`
  MODIFY `complaint_id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `meal`
--
ALTER TABLE `meal`
  MODIFY `meal_id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `remaining_inventory`
--
ALTER TABLE `remaining_inventory`
  MODIFY `inventory_id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `school_login`
--
ALTER TABLE `school_login`
  MODIFY `school_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `student`
--
ALTER TABLE `student`
  MODIFY `student_id` int(25) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `supplier`
--
ALTER TABLE `supplier`
  MODIFY `sp_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
